<div align="center">

# 🤖 3-Link Planar Robotic Arm
### Forward Kinematics Simulation | MATLAB

**From joint angles to end-effector position**

![MATLAB](https://img.shields.io/badge/MATLAB-Simulation-orange?style=for-the-badge&logo=mathworks&logoColor=white)
![Robotics](https://img.shields.io/badge/Domain-Robotics-blue?style=for-the-badge)
![Kinematics](https://img.shields.io/badge/Topic-Forward%20Kinematics-purple?style=for-the-badge)

</div>

---

## 📌 Project Overview

This project demonstrates **Forward Kinematics (FK)** for a 3-link planar robotic arm using MATLAB. Given three joint angles and three link lengths, the program calculates the end-effector's position and orientation in the XY plane using homogeneous transformation matrices.

## 🎯 Objectives

- Create transformation matrices for three revolute joints.
- Combine the transformations into a base-to-end-effector matrix.
- Calculate the end-effector's X and Y coordinates.
- Determine the final orientation of the robotic arm.
- Display the final transformation matrix in MATLAB.

## 🦾 Robot Parameters

The values visible in the supplied MATLAB simulation are:

| Parameter | Value | Description |
|:--|:--:|:--|
| `t1` | 30° | Joint 1 angle |
| `t2` | 45° | Joint 2 angle |
| `t3` | -20° | Joint 3 angle |
| `l1` | 1 | Link 1 length |
| `l2` | 2 | Link 2 length |
| `l3` | 2 | Link 3 length |

> **Note:** Angles are in degrees; the implementation uses MATLAB's `cosd()` and `sind()` functions.

## 🖥️ MATLAB Simulation

The screenshot below shows the MATLAB editor, the plotted 3-link robot, workspace values, and the final transformation matrix.

![MATLAB simulation of the 3-link planar robot](assets/matlab-simulation.png)

## ⚙️ Forward Kinematics

Each link is represented by a homogeneous transformation matrix:

\[
T_{i-1,i} =
\begin{bmatrix}
\cos t_i & -\sin t_i & 0 & l_i\cos t_i\\
\sin t_i & \cos t_i & 0 & l_i\sin t_i\\
0 & 0 & 1 & 0\\
0 & 0 & 0 & 1
\end{bmatrix}
\]

The transformations are multiplied in sequence:

\[
T_{02}=T_{01}T_{12}
\]

\[
\boxed{T_{03}=T_{01}T_{12}T_{23}}
\]

`T03` represents the transformation from the base frame to the end-effector frame.

## 📐 Mathematical Model

**End-effector X-coordinate**

\[
X=l_1\cos t_1+l_2\cos(t_1+t_2)+l_3\cos(t_1+t_2+t_3)
\]

**End-effector Y-coordinate**

\[
Y=l_1\sin t_1+l_2\sin(t_1+t_2)+l_3\sin(t_1+t_2+t_3)
\]

**Final orientation**

\[
\phi=t_1+t_2+t_3
\]

The final transformation matrix is:

\[
T_{03} =
\begin{bmatrix}
\cos\phi & -\sin\phi & 0 & X\\
\sin\phi & \cos\phi & 0 & Y\\
0 & 0 & 1 & 0\\
0 & 0 & 0 & 1
\end{bmatrix}
\]

## 📊 Simulation Results

For the parameters above, the MATLAB output is approximately:

**Final Transformation Matrix**

```text
    0.5736   -0.8192         0    2.6602
    0.8192    0.5736         0    4.5531
         0         0    1.0000         0
         0         0         0    1.0000
```

**End-Effector Position**

```text
X = 2.6602
Y = 4.5531
```

**Final orientation:** 55°

Extract the XY position in MATLAB with:

```matlab
endEffectorPosition = T03(1:2, 4);
```

## 💻 Core MATLAB Code

```matlab
% Combine the three transformations
T02 = t01 * t12;
T03 = T02 * t23;

% Extract end-effector X and Y coordinates
endEffectorPosition = T03(1:2, 4);

% Display results
disp('Final Transformation Matrix:');
disp(T03);

disp('End Effector Position:');
disp(endEffectorPosition);
```

## ▶️ How to Run

1. Open MATLAB.
2. Open the folder containing the project `.m` files.
3. Set that folder as the MATLAB Current Folder.
4. Run `main_simulation.m`.
5. View the robot plot in the Figure window and the matrix in the Command Window.

## 🧰 Tools & Concepts

| Tool / Concept | Purpose |
|:--|:--|
| MATLAB | Implementation and simulation |
| Linear Algebra | Matrix multiplication |
| Homogeneous Transformations | Position and orientation representation |
| Forward Kinematics | End-effector position calculation |
| 2D Plotting | Visualizing the robotic arm |

## 🚀 Future Improvements

- Animate the robotic arm as joint angles change.
- Plot the end-effector trajectory.
- Implement inverse kinematics.
- Add joint limits and workspace visualization.
- Extend the model to a 3D robotic manipulator.

## 🌍 Applications

- Industrial robotic manipulators
- Pick-and-place systems
- Robot motion planning
- Robotics education and simulation
- Automated positioning systems

---

<div align="center">

### ⭐ 3-Link Planar Robotic Arm
**Forward Kinematics | MATLAB**

*Understanding the mathematics behind robotic motion.*

</div>
